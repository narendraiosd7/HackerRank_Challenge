//
//  ViewController.swift
//  SimmpleArraySum
//
//  Created by Vadde Narendra on 3/28/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        simpleArraySum(ar: [1,2,2,2])
        print(simpleArraySumUsingForLoop(ar: [1,9,190,800]))
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // MARK:- reduce method for doing sum of all eliments in an array

    func simpleArraySum(ar: [Int]) -> Int {
        
        let dataSum = ar.reduce(0, +)
        print(dataSum)
        return dataSum
        
    }
    
    // MARK:- For loop method for doing sum of all eliments in an array
    
    func simpleArraySumUsingForLoop(ar:[Int]) -> Int {
        var index:Int  = 0
        var result:Int = 0
        
        for _ in ar{
            result += ar[index]
            
            index += 1
        }
        
        return result
    }
    
    
}

