//
//  ViewController.swift
//  SimmpleArraySum
//
//  Created by Vadde Narendra on 3/28/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        simpleArraySum(ar: [1,2,2,2])
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func simpleArraySum(ar: [Int]) -> Int {
        /*
         * Write your code here.
         */
        let dataSum = ar.reduce(0, +)
        print(dataSum)
        return dataSum
        
    }
    
}

