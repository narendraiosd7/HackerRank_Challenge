//
//  ViewController.swift
//  ABigSum
//
//  Created by Vadde Narendra on 4/2/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        print(aVeryBigSum(ar: [1000000001, 1000000002, 1000000003, 1000000004, 1000000005]))
        
        print(aVeryBigSumReduceMethod(ar: [1000000001, 1000000002, 1000000003, 1000000004, 1000000005]))
        // Do any additional setup after loading the view.
    }

    //MARK:- using for loop method
    
    func aVeryBigSum(ar: [Int]) -> Int {

        var result = 0
        var index = 0

        for _ in ar {
            result += ar[index]
            index += 1

        }

        return result
    }
    
    //MARK:- using reduce method
    
    var sumResult = 0
    
    func aVeryBigSumReduceMethod(ar:[Int]) -> Int {
        sumResult = ar.reduce(0, +)
        return sumResult
    }
    
    
}

