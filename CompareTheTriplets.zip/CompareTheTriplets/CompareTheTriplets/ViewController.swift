//
//  ViewController.swift
//  CompareTheTriplets
//
//  Created by Vadde Narendra on 3/31/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        compareTriplets(a: [0,1,2], b: [3,4,5])
        
        // Do any additional setup after loading the view.
    }

    
    func compareTriplets(a: [Int], b: [Int]) -> [Int] {
        var total = [0,0]

       for x in 0..<a.count {
          if a[x] > b[x] {
             total[0] += 1
          } else if a[x] < b[x] {
            total[1] += 1
          }
       }
        print(total)
        
       return  total
        
        

    }

}

